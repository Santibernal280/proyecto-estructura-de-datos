import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Registro_Internet {

    // Atributos para registrar el consumo de internet y exceso de costo
    private Double consumoDatos;
    private String fechaConsumo;

    // Lista para almacenar el historial de consumo de datos
    private List<Registro_Internet> historialConsumo;

    public Registro_Internet() {
        historialConsumo = new ArrayList<>();
    }

    // Getters y Setters
    public Double getConsumoDatos() {
        return consumoDatos;
    }

    public void setConsumoDatos(Double consumoDatos) {
        this.consumoDatos = consumoDatos;
    }

    public String getFechaConsumo() {
        return fechaConsumo;
    }

    public void setFechaConsumo(String fechaConsumo) {
        this.fechaConsumo = fechaConsumo;
    }

    public List<Registro_Internet> getHistorialConsumo() {
        return historialConsumo;
    }

    // Método para registrar el consumo de datos diario
    public void registrarConsumoDiario(Double datosConsumidos) {
        Registro_Internet registro = new Registro_Internet();
        registro.setConsumoDatos(datosConsumidos);
        registro.setFechaConsumo(new Date().toString());
        historialConsumo.add(registro);
    }

    // Método para calcular los costos por exceso de datos
    public double calcularCostosPorExceso(Double limiteDatos, Double tarifaPorGBExtra) {
        double totalExceso = 0;
        for (Registro_Internet registro : historialConsumo) {
            if (registro.getConsumoDatos() > limiteDatos) {
                totalExceso += (registro.getConsumoDatos() - limiteDatos);
            }
        }
        return totalExceso * tarifaPorGBExtra;
    }
}
