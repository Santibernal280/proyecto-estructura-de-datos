public class Cliente {
    //atributos del cliente
    private int Id_Cliente; //Cedula
    private String Cliente;
    private String Direccion;
    private String Correo;
    //Aca se registra el codigo del plan de internet al que vaya a comprar el cliente
    private int ServicioInternet;
    private double Celular;
    //Identificador unico, lo genera el mismo programa
    private String Id_unico;


    //Creo los metodos constructor (Vacio, lleno y uno para inicializar el Id unico)

    public Cliente() {
    }

    public Cliente(int id_Cliente) {
        Id_Cliente = id_Cliente;
    }

    public Cliente(int id_Cliente, String cliente, String direccion, String correo,
                   int servicioInternet, double celular, String id_unico) {
        Id_Cliente = id_Cliente;
        Cliente = cliente;
        Direccion = direccion;
        Correo = correo;
        ServicioInternet = servicioInternet;
        Celular = celular;
        Id_unico = id_unico;
    }

    //Creo los metodos get and set

    public int getServicioInternet() {
        return ServicioInternet;
    }

    public void setServicioInternet(int servicioInternet) {
        ServicioInternet = servicioInternet;
    }

    public int getId_Cliente() {
        return Id_Cliente;
    }

    public void setId_Cliente(int id_Cliente) {
        Id_Cliente = id_Cliente;
    }

    public String getCliente() {
        return Cliente;
    }

    public void setCliente(String cliente) {
        Cliente = cliente;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String direccion) {
        Direccion = direccion;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }

    public double getCelular() {
        return Celular;
    }

    public void setCelular(double celular) {
        Celular = celular;
    }

    public String getId_unico() {
        return Id_unico;
    }

    public void setId_unico(String id_unico) {
        Id_unico = id_unico;
    }

    /*
    Creo el metodo toString
    Repesenta una cadena que deuelve todas las propiedades del objeto Cliente
     */

    @Override
    public String toString() {
        return "Cliente \n" +
                "Id_Cliente=" + Id_Cliente + '\n' +
                ", Cliente='" + Cliente + '\n' +
                ", Direccion='" + Direccion + '\n' +
                ", Correo='" + Correo + '\n' +
                ", ServicioInternet=" + ServicioInternet + '\n' +
                ", Celular=" + Celular + '\n' +
                ", Id_unico=" + Id_unico ;
    }

    //
    @Override
    public int hashCode() {
        int hash = 5;

        return hash;
    }

    //creo metodos para realizar la commparacion en las busquedas
    @Override
    public boolean equals (Object obj) {

        if (this == obj) {

            return true;

        }
        if (obj == null) {

            return false;

        }

        if (getClass() != obj.getClass()) {

            return false;

        }

        final Cliente other = (Cliente) obj;
        return this.Id_Cliente == other.Id_Cliente;
    }
}
