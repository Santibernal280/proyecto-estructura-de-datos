import javax.swing.*;
import java.util.Random;

public class CLARO_MOBILE {
    private GestionInternet gestionInternet;
    private GestionCliente gestionCliente;
    private PlanInternet p = new PlanInternet();
    private Cliente c = new Cliente();
    private Registro_Internet registroInternet;
    //nos servira como base para geberar codigos aleatorios de productos
    private final int vect[] = {10, 20, 30, 40, 50, 60, 70};

    public static void main(String[] args) {
        /*
        La instancia app se crea para permitir la interacción con los métodos no estáticos de la clase Hrmobile.
         En Java, el método main() debe ser estático, lo que significa que no puede acceder directamente a los métodos
         no estáticos de la clase a menos que se cree una instancia de la clase.

        La instancia app se crea para poder llamar al método init(), que no es estático.
        El método init() es responsable de iniciar la interacción con el usuario y controlar el flujo principal del programa.
         */
        CLARO_MOBILE app = new CLARO_MOBILE();

        app.init();
    }

    public void init() {
        gestionInternet = new GestionInternet();//Inicializo el objeto
        gestionCliente = new GestionCliente(gestionInternet); // Inicializo el objeto
        registroInternet = new Registro_Internet(); // Inicializo el objeto
        String Option = "";

        do {
            Option = JOptionPane.showInputDialog(null,
                    "-*-*-*-*-*-*-*-* BIENVENIDOS A CLARO MOBILE -*-*-*-*-*-*-*-* \n" +
                            "Seleccione una de las opciones: \n" +
                            "A. Registro o Modificacion de Planes de Servicios de Snternet \n" +
                            "B. Creacion o Registro de Clientes \n" +
                            "C. Registro y Monitorización del Uso de Datos \n" +
                            "D. Exit");

            switch (Option.charAt(0)) {
//PRIMERA OPCION, MENU PRINCIPAL (PLANES DE INTERNET)
                case 'A': case 'a':

                    do {
                        Option = JOptionPane.showInputDialog(null,
                                "-*-*-*-*-*-*-*- PROGRAMA GESTION DE PLANES DE INTERNET -*-*-*-*-*-*-*-* \n" +
                                        "A. Registrar Plan de internet \n" +
                                        "B. Actualizar informacion del Plan de internet \n" +
                                        "C. Buscar un producto \n" +
                                        "D. Eliminar producto \n" +
                                        "E. Mostrar lista de servicios de Planes de internet \n" +
                                        "F. Regresar al menu principal  \n" +
                                        "Digite una opcion por favor.");

                        switch (Option.charAt(0)) {

                            case 'A': case 'a':
                                RegistrarPlan();
                                break;

                            case 'B': case 'b':
                                ActualizarPlan();
                                break;

                            case 'C': case 'c':
                                BuscarPlan();
                                break;

                            case 'D': case 'd':
                                EliminadorPlan();
                                break;

                            case 'E': case 'e':
                                gestionInternet.ListarPlanes();
                                break;

                            case 'F': case 'f':
                                JOptionPane.showMessageDialog(null,
                                        "Regresando al menu principal.....");
                                break;

                            default:
                                JOptionPane.showMessageDialog(null,
                                        "Wrong Option :(, Try it again");
                                break;
                        }
                    } while (!Option.equalsIgnoreCase("F"));
                    break;

//SEGUNDA OPCION, MENU PRINCIPAL (CLIENTES)
                case 'B': case 'b':

                    do {
                        Option = JOptionPane.showInputDialog(null,
                                "-*-*-*-*-*-*-*- PROGRAMA GESTION DE CLIENTES -*-*-*-*-*-*-*-* \n" +
                                        "A. Registrar Cliente \n" +
                                        "B. Actualizacion de datos \n" +
                                        "C. Consulta de Clientes \n" +
                                        "D. Regresar al menu principal  \n" +
                                        "Digite una opcion por favor.");

                        switch (Option.charAt(0)) {

                            case 'A': case 'a':
                                gestionCliente.NewClient();
                                break;

                            case 'B': case 'b':
                                ActualizarCliente();
                                break;

                            case 'C': case 'c':
                                BuscarCliente();
                                break;

                            case 'D': case 'd':
                                JOptionPane.showMessageDialog(null,
                                        "Regresando al menu principal.....");
                                break;

                            default:
                                JOptionPane.showMessageDialog(null,
                                        "Wrong Option :(, Try it again");
                                break;
                        }
                    } while (!Option.equalsIgnoreCase("D"));
                    break;

//TERCERA OPCION, MENU PRINCIPAL
                case 'C': case 'c':

                    do {
                        Option = JOptionPane.showInputDialog(null,
                                "-*-*-*-*-*-*-*- PROGRAMA GESTION DE USO DE DATOS -*-*-*-*-*-*-*-* \n" +
                                        "A. Registrar Consumo Diario \n" +
                                        "B. Ver Historial de Consumo \n" +
                                        "C. Calcular Costos por Exceso \n" +
                                        "D. Regresar al menu principal  \n" +
                                        "Digite una opcion por favor.");

                        switch (Option.charAt(0)) {
                            case 'A': case 'a':
                                registrarConsumoDiario();
                                break;

                            case 'B': case 'b':
                                verHistorialConsumo();
                                break;

                            case 'C': case 'c':
                                calcularCostosPorExceso();
                                break;

                            case 'D': case 'd':
                                JOptionPane.showMessageDialog(null,
                                        "Regresando al menu principal.....");
                                break;

                            default:
                                JOptionPane.showMessageDialog(null,
                                        "Wrong Option :(, Try it again");
                                break;
                        }
                    } while (!Option.equalsIgnoreCase("D"));
                    break;

//CUARTA OPCION, MENU PRINCIPAL
                case 'D': case 'd':
                    JOptionPane.showMessageDialog(null,
                            "Saliendo del sistema.....");
                    break;

                default:
                    JOptionPane.showMessageDialog(null,
                            "Wrong Option :(, Try it again");
                    break;
            }
        } while (!Option.equalsIgnoreCase("C")) ;
    }

//CREACION O IMPLEMENTACION DE METODOS PARA LOS PLANES DE INTERNET

    //GENERACION DE CODIGOS PARA IDENTIFICAR LOS PLANES
    int generaCodigoPlan() {
        Random r = new Random();
        int tam = vect.length - 1;
        return r.nextInt( 100) + vect[tam];
    }
    //PRIMER METODO
    void RegistrarPlan () {

        int codigoPlan = generaCodigoPlan();
        JOptionPane.showMessageDialog(null,
                "Código de plan: " + codigoPlan + "\n");
        String Plan = JOptionPane.showInputDialog(null,
                "Nombre del plan: ");
        String TipoPlan = JOptionPane.showInputDialog(null,
                "Tipo del plan (Limitado o Ilimitado): ");
        double limiteDatos = Double.parseDouble(JOptionPane.showInputDialog(null,
                "Cual es el limite de datos en el plan (GB): "));
        double Velocidad = Double.parseDouble(JOptionPane.showInputDialog(null,
                "Velocidad del plan (Mbps): "));
        double Costo = Double.parseDouble(JOptionPane.showInputDialog(null,
                "Precio inicial: "));
        int Contrato = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Permanencia del contrato (Tiempo estipulado en meses): "));
        String Servicios_Add = JOptionPane.showInputDialog(null,
                "Servicios adicionales del plan: ");

        gestionInternet.NewPlan (codigoPlan, Plan, TipoPlan, limiteDatos, Velocidad,
                Costo, Contrato, Servicios_Add);
    }

    //SEGUNDO METODO
    void ActualizarPlan () {
    JOptionPane.showMessageDialog(null,
                "Actualización del Plan de internet");
        int codigoPlan = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Digite código del PLan: "));
        p = gestionInternet.BuscarPlan(codigoPlan);

        if (p != null) {

            JOptionPane.showMessageDialog(null,
                    "Nombre producto: " + p.getPlan());

            JOptionPane.showMessageDialog(null,
                    "Tipo actual: " + p.getTipoPlan());
            String TypePlan = JOptionPane.showInputDialog(null,
                    "Digite el tipo de dato a agregar: ");

            JOptionPane.showMessageDialog(null,
                    "Limite de datos actual: " + p.getLimiteDatos());
            double Datos = Double.parseDouble(JOptionPane.showInputDialog(null,
                    "Digite el limite de datos a agregar: "));

            JOptionPane.showMessageDialog(null,
                    "Costo actual: " + p.getCosto());
            double Precio = Double.parseDouble(JOptionPane.showInputDialog(null,
                    "Digite el costo a agregar"));

            gestionInternet.UpdatePlan(codigoPlan, TypePlan, Datos, Precio);

        } else {

            JOptionPane.showMessageDialog(null,
                    "El código digitado, no existe!");
        }
    }

    //TERCER METODO
    void BuscarPlan() {
        int codigoPlan = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Digite código del Plan: "));
        p = gestionInternet.BuscarPlan(codigoPlan);

        if (p != null) {
            JOptionPane.showMessageDialog(null, p.toString(), "Información del Plan",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "El código digitado no existe!");
        }
    }


    //CUARTO METODO
    void EliminadorPlan() {
        JOptionPane.showMessageDialog(null,
                "Eliminación de producto");

        int codigoPlan = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Digite código del PLan: "));
        p = gestionInternet.BuscarPlan(codigoPlan);

        if (p != null) {

            gestionInternet.EliminarPlan(codigoPlan);

        } else {

            JOptionPane.showMessageDialog(null,
                    "El código de producto digitado, no existe!");
        }
    }
//CREACION O IMPLEMENTACION DE METODOS PARA LOS CLIENTES
        //SEGUNDO METODO PARA ACTUALIZAR EL PLAN DE SERVICIOS DEL CLIENTE
    void ActualizarCliente () {
        JOptionPane.showMessageDialog(null,
                "Actualización del Cliente");
        int id_Cliente = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Digite el numero de identificacion del cliente: "));
        c = gestionCliente.SearchClient(id_Cliente);

        if (c != null) {

            JOptionPane.showMessageDialog(null,
                   "Plan de servicio actual: " + c.getServicioInternet());
            int CambioServicio = Integer.parseInt(JOptionPane.showInputDialog(null,
                   "Digite el codigo del plan de internet, al cual va a actualizar "));
            // Verificar si el código del plan existe
            if (!gestionInternet.existePlan(CambioServicio)) {
                JOptionPane.showMessageDialog(null, "El código del plan de servicio de internet no existe. Por favor, ingrese un código válido.");
                return;
            }

            gestionCliente.UpdateClient(id_Cliente, CambioServicio);

        } else {

           JOptionPane.showMessageDialog(null,
                 "El código digitado, no existe!");
        }
    }
        //TERCER METODO PARA CONSULTAR UN CLIENTE
    void BuscarCliente() {
        int id_Cliente = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Digite el numero de identificacion del cliente: "));
        c = gestionCliente.SearchClient(id_Cliente);
        if (p != null) {
            JOptionPane.showMessageDialog(null, c.toString(), "Información del Cliente",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "El id digitado no existe!");
        }
    }

//CREACION O IMPLEMENTACION DE METODOS PARA EL REGISTRO DE USO DE DATOS
    private void registrarConsumoDiario() {
        Double datosConsumidos = Double.parseDouble(JOptionPane.showInputDialog(null,
                "Ingrese la cantidad de datos consumidos hoy (GB): "));
        registroInternet.registrarConsumoDiario(datosConsumidos);
        JOptionPane.showMessageDialog(null, "Consumo diario registrado exitosamente.");
    }

    private void verHistorialConsumo() {
        StringBuilder historial = new StringBuilder();
        for (Registro_Internet registro : registroInternet.getHistorialConsumo()) {
            historial.append("Fecha: ").append(registro.getFechaConsumo())
                    .append(", Datos Consumidos: ").append(registro.getConsumoDatos()).append(" GB\n");
        }
        JOptionPane.showMessageDialog(null, historial.toString(), "Historial de Consumo",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // Método para calcular el costo por exceso de datos
    PlanInternet BuscarPlan(int codigoPlan) {
        return gestionInternet.BuscarPlan(codigoPlan);
    }
    private void calcularCostosPorExceso() {
        int codigoPlan = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Ingrese el código del plan de Internet: "));
        PlanInternet plan = BuscarPlan(codigoPlan);

        if (plan != null) {
            // Obtener el límite de datos del plan específico
            double limiteDatos = plan.getLimiteDatos();
            Double tarifaPorGBExtra = Double.parseDouble(JOptionPane.showInputDialog(null,
                    "Ingrese la tarifa por GB extra: $"));
            double costoExceso = registroInternet.calcularCostosPorExceso(limiteDatos, tarifaPorGBExtra);
            JOptionPane.showMessageDialog(null,
                    "El costo total por exceso de datos es: $" + costoExceso);
        } else {
            JOptionPane.showMessageDialog(null,
                    "El plan de Internet con el código dado no existe.");
        }
    }

}