import javax.swing.*;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
public class GestionCliente {
    /*
    Creo un atributo que representa donde se almacenan los objetos clientes.
     private = este atributo solo es accesible desde la clase actual.
     La palabra clave final indica que este atributo no se puede reasignar una vez que se inicializa.
     List<Cliente> especifica que la lista contiene objetos de la clase Cliente.
     */
    private final List<Cliente> ListaClientes;
    private final GestionInternet gestionInternet;

    //Creo una nueva instancia de la clase LinkedList, ofrece eficiencia en operaciones de inserción y eliminación.

    public GestionCliente(GestionInternet gestionInternet) {
        this.ListaClientes = new LinkedList<>();
        this.gestionInternet = gestionInternet; // Y esta línea
    }


    // GENERACION DE IDENTIFICADOR UNICO
    private final String vect[] = {"HR_ABC", "HR_DBC", "HR_PRC", "HR_JKC", "HR_LMC", "HR_WYC", "HR_PQC"};
    private final int valores[] = {50912, 80912, 90912, 100912, 45912, 63912};
    String GeneracionIdUnico() {
        Random r = new Random();
        int indexVect = r.nextInt(vect.length);
        int indexValores = r.nextInt(valores.length);
        return vect[indexVect] + valores[indexValores];
    }

    // GESTION DE CLIENTES
    //Primera Funcionalidad (Crear o registrar Clientes)
    public void NewClient() {
        int id_Cliente = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Ingrese el numero de identificacion del cliente): "));
        String cliente = JOptionPane.showInputDialog(null,
                "Ingrese nombre del cliente: ");
        String direccion = JOptionPane.showInputDialog(null,
                "Ingrese la direccion del cliente): ");
        String correo = JOptionPane.showInputDialog(null,
                "Ingrese el correo electronico del cliente): ");
        int servicioInternet = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Ingrese el codigo del plan de internet, al que el cliente va a comprar"));
        double celular = Double.parseDouble(JOptionPane.showInputDialog(null,
                "Ingrese el numero de celular al que va a ser vinculado el plan de internet"));
        String id_unico = GeneracionIdUnico();
        JOptionPane.showMessageDialog(null,
                "Su numero de identificacion unico es: "+ id_unico);

        // Verificar si el código del plan existe
        if (!gestionInternet.existePlan(servicioInternet)) {
            JOptionPane.showMessageDialog(null, "El código del plan de servicio de internet no existe. Por favor, ingrese un código válido.");
            return;
        }

        Cliente ClienteNuevo = new Cliente(id_Cliente, cliente, direccion, correo,
                servicioInternet, celular, id_unico);

        boolean exito = ListaClientes.add(ClienteNuevo);

        if (exito) {
            JOptionPane.showMessageDialog(null,
                    "El Cliente " + ClienteNuevo.getCliente() +
                            ", fue agregado exitosamente!");
        } else {
            JOptionPane.showMessageDialog(null,
                    "Ocurrio un problema de registro, del plan: " +
                            ClienteNuevo.getCliente());
        }
    }

    //Segunda Funcionalidad (Actualizar la informacion del cliente)
    public void UpdateClient(int id_Cliente, int CambioServicio){

        //Traigo los datos del cliente, segun la cedula
        int indice = ListaClientes.indexOf(new Cliente (id_Cliente));

        Cliente Persona = ListaClientes.get(indice);

        if (Persona != null) {

            /*Traigo los valores anteriores
            Ejm: Ant (anterior tipo de plan), traigo el dato para luego actualizarlo
            */
            int AntPlanDeInternet = Persona.getServicioInternet();

            /*
            Creo un nuevo atributo para actualizar el dato
             */
            int NewServicioInternet = CambioServicio;

            /*
            Agrego los nuevos valores
             */
            Persona.setServicioInternet (NewServicioInternet);

            /*
            Arrojo un mensaje de verificacion
             */
            JOptionPane.showInputDialog(null,
                    "Se actualizó el servicio de internet de "
                            + Persona.getCliente()+" de "
                            + AntPlanDeInternet + " a " + NewServicioInternet );
        } else {

            JOptionPane.showInputDialog(null,
                    "Ocurrió un problema de actualización");

        }
    }
    //Tercera Funcionalidad (Buscar Cliente)
    public Cliente SearchClient (int id_Cliente) {

        //Traigo los datos del cliente, segun la cedula
        int indice = ListaClientes.indexOf(new Cliente (id_Cliente));

        return ListaClientes.get(indice);
    }
}
