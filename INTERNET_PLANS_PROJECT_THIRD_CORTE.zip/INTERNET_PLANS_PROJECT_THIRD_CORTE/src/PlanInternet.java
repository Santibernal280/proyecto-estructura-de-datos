public class PlanInternet {
    //atributos para los planes
    private int CodigoPlan; //Identificar el plan
    private String Plan; //Nombre (Plan Básico, intermedio, avanzado, etc)
    private String TipoPlan; //Tipo de plan (limitado o ilimitado)
    private double LimiteDatos; //cantidad de datos que ofrece el plan
    private double Velocidad;//Velocidad de descarga y subida Mbps
    private double Costo; //Costo del plan
    private int Contrato; //Tiempo en que el cliente debe permanecer con el plan
    private String Servicios_Add;//Servicios adicionales (Tv, Telefonia)

    //Creo los metodos constructor (Vacio, lleno y uno para inicializar el codigo)

    public PlanInternet() {
    }

    public PlanInternet(int codigoPlan) {
        this.CodigoPlan = codigoPlan;
    }

    public PlanInternet(int codigoPlan, String plan, String tipoPlan, double limiteDatos,
                        double velocidad, double costo, int contrato, String servicios_Add) {
        CodigoPlan = codigoPlan;
        Plan = plan;
        TipoPlan = tipoPlan;
        LimiteDatos = limiteDatos;
        Velocidad = velocidad;
        Costo = costo;
        Contrato = contrato;
        Servicios_Add = servicios_Add;
    }

    //Creo los metodos get and set

    public double getLimiteDatos() {
        return LimiteDatos;
    }

    public void setLimiteDatos(double limiteDatos) {
        LimiteDatos = limiteDatos;
    }

    public int getCodigoPlan() {
        return CodigoPlan;
    }

    public void setCodigoPlan(int codigoPlan) {
        this.CodigoPlan = codigoPlan;
    }

    public String getPlan() {
        return Plan;
    }

    public void setPlan(String plan) {
        Plan = plan;
    }

    public String getTipoPlan() {
        return TipoPlan;
    }

    public void setTipoPlan(String tipoPlan) {
        TipoPlan = tipoPlan;
    }

    public double getVelocidad() {
        return Velocidad;
    }

    public void setVelocidad(double velocidad) {
        Velocidad = velocidad;
    }

    public double getCosto() {
        return Costo;
    }

    public void setCosto(double costo) {
        Costo = costo;
    }

    public int getContrato() {
        return Contrato;
    }

    public void setContrato(int contrato) {
        Contrato = contrato;
    }

    public String getServicios_Add() {
        return Servicios_Add;
    }

    public void setServicios_Add(String servicios_Add) {
        Servicios_Add = servicios_Add;
    }


    /*
    Creo el metodo toString
    Repesenta una cadena que deuelve todas las propiedades del objeto Cliente
     */

    @Override
    public String toString() {
        return "Código del plan: " + CodigoPlan + "\n" +
                "Nombre del plan: " + Plan + "\n" +
                "Tipo del plan: " + TipoPlan + "\n" +
                "Límite de datos del plan: " + LimiteDatos + " GB\n" +
                "Velocidad del plan: " + Velocidad + " Mbps\n" +
                "Costo del plan: $" + Costo + "\n" +
                "Servicios adicionales del plan: " + Servicios_Add + "\n";
    }


    //
    @Override
    public int hashCode() {
        int hash = 5;

        return hash;
    }

    //creo metodos para realizar la commparacion en las busquedas
    @Override
    public boolean equals (Object obj) {

        if (this == obj) {

            return true;

        }
        if (obj == null) {

            return false;

        }

        if (getClass() != obj.getClass()) {

            return false;

        }

        final PlanInternet other = (PlanInternet) obj;
        return this.CodigoPlan == other.CodigoPlan;
    }
}