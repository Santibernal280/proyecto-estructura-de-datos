import javax.swing.*;
import java.util.LinkedList;
import java.util.List;

public class GestionInternet {
    /*
    Creo un atributo que representa donde se almacenan los objetos clientes.
     private = este atributo solo es accesible desde la clase actual.
     La palabra clave final indica que este atributo no se puede reasignar una vez que se inicializa.
     List<Cliente> especifica que la lista contiene objetos de la clase Cliente.
     */
    private final List<PlanInternet> ListaPlanes;

    //Creo una nueva instancia de la clase LinkedList, ofrece eficiencia en operaciones de inserción y eliminación.
    public GestionInternet() {
        ListaPlanes = new LinkedList<>();

    }

    // GESTION DE PLANES
    //Primera Funcionalidad (Crear o registrar los planes de internet)
    public void NewPlan(int codigoPlan, String Plan, String TipoPlan, double limiteDatos, double Velocidad,
                        double Costo, int Contrato, String Servicios_Add){

        PlanInternet PlanNuevo = new PlanInternet(codigoPlan, Plan, TipoPlan, limiteDatos, Velocidad,
                Costo, Contrato, Servicios_Add);

        boolean exito = ListaPlanes.add(PlanNuevo);

        if (exito){
            JOptionPane.showInputDialog(null,
                    "El plan "+ PlanNuevo +
                            ", fue agregado exitosamente!");
        }else {
            JOptionPane.showInputDialog(null,
                    "Ocurrio un problema de registro, del plan: "+
                            PlanNuevo.getPlan());
        }

    }

    //Segunda Funcionalidad (Actualizar el plan en el costo y limite de datos)
    public void UpdatePlan(int codigoPlan, String TypePlan, double Datos, double Precio){

        //Traigo los datos del plan, segun el codigo que traiga
        int indice = ListaPlanes.indexOf(new PlanInternet (codigoPlan));

        PlanInternet Plan = ListaPlanes.get(indice);

        if (Plan != null) {

            /*Traigo los valores anteriores
            Ejm: Ant (anterior tipo de plan), traigo el dato para luego actualizarlo
            */
            String AntTipoPlan = Plan.getTipoPlan();
            double AntlimiteDatos = Plan.getLimiteDatos();
            double AntCosto = Plan.getCosto();

            /*
            Creo un nuevo atributo para actualizar el dato
             */
            String NewTipoPlan = TypePlan;
            double NewlimiteDatos = Datos;
            double NewCosto = Precio;

            /*
            Agrego los nuevos valores
             */
            Plan.setTipoPlan (NewTipoPlan);
            Plan.setLimiteDatos (NewlimiteDatos);
            Plan.setCosto (NewCosto);

            /*
            Arrojo un mensaje de verificacion
             */
            JOptionPane.showInputDialog(null,
                    "Se actualizó el tipo de plan de "
                            + Plan.getPlan()+" de "
                            + AntTipoPlan + " a " + NewTipoPlan + "\n" +
                            "Tambien se atualizo los limites de datos de "
                            + AntlimiteDatos + " a "+ NewlimiteDatos + "\n"
                            + " y se actualizo el coto de $"
                            + AntCosto + " a "+ "$" + NewCosto);
        } else {

            JOptionPane.showInputDialog(null,
                    "Ocurrió un problema de actualización" +
                            "del plan ");

        }
    }
    //Tercera Funcionalidad (Buscar Planes)
    public PlanInternet BuscarPlan (int codigoPlan) {

        int indice = ListaPlanes.indexOf(new PlanInternet(codigoPlan));

        return ListaPlanes.get(indice);
    }

    //Cuarta Funcionalidad (Eliminador de Planes)
    public void EliminarPlan(int codigoPlan){
        int indice = ListaPlanes.indexOf(new PlanInternet(codigoPlan));

        PlanInternet Plan = ListaPlanes.get(indice);

        if (Plan != null){
            JOptionPane.showInputDialog(null,
                    "Se ha eliminado completamente" );
        }else {
            JOptionPane.showInputDialog(null,
                    "Ha ocurrido un error");
        }
    }

    //Quinta Funcionalidad (Listar los planes)
    public void ListarPlanes() {
        StringBuilder message = new StringBuilder("Listado de Planes de internet:\n");
        ListaPlanes.forEach(planInternet -> JOptionPane.showMessageDialog(null, planInternet,
                "Plan de internet", JOptionPane.INFORMATION_MESSAGE));
    }

    public boolean existePlan(int codigoPlan) {
        for (PlanInternet plan : ListaPlanes) { // Cambié 'planes' por 'ListaPlanes'
            if (plan.getCodigoPlan() == codigoPlan) {
                return true;
            }
        }
        return false;
    }

}